<?php $anatomy_face = $this->options; ?>
<form method="post" action="<?php echo admin_url( '/' ); ?>admin.php?page=anatomy-face">
<div id="anatomy-admin">
  <div id="anatomy-header">
    <p class="anatomy-shortcode">Insert this shortcode <input type="text" value="[anatomy_face]" readonly> into any page or post to display the interactive drawing. &nbsp; | &nbsp; <span class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></span></p>
  </div>
  <div id="anatomy-page">
    <div class="anatomy-col-lt">
      <div id="anatomy-preview">
        <?php include 'anatomy.php'; ?>
      </div>
      <div class="anatomy-settings">
        <div class="box-header individ-i">Settings</div>
        <div class="box-body">

          <div class="org-area"><p class="area-name">FULL FACE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_1" value="1" <?php if ($anatomy_face['enabled_1'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_1" value="<?php echo $anatomy_face['url_1']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_1">
                    <option value="same_window" <?php if($anatomy_face['turl_1'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_1'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_1'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_1"><?php echo $anatomy_face['info_1']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">FOREHEAD</p>
            <span class="chkbx"><input type="checkbox" name="enabled_2" value="1" <?php if ($anatomy_face['enabled_2'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_2" value="<?php echo $anatomy_face['url_2']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_2">
                    <option value="same_window" <?php if($anatomy_face['turl_2'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_2'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_2'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_2"><?php echo $anatomy_face['info_2']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">EYE [RT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_3" value="1" <?php if ($anatomy_face['enabled_3'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_3" value="<?php echo $anatomy_face['url_3']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_3">
                    <option value="same_window" <?php if($anatomy_face['turl_3'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_3'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_3'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_3"><?php echo $anatomy_face['info_3']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">EYE [LT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_4" value="1" <?php if ($anatomy_face['enabled_4'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_4" value="<?php echo $anatomy_face['url_4']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_4">
                    <option value="same_window" <?php if($anatomy_face['turl_4'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_4'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_4'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_4"><?php echo $anatomy_face['info_4']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">NOSE</p>
            <span class="chkbx"><input type="checkbox" name="enabled_5" value="1" <?php if ($anatomy_face['enabled_5'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_5" value="<?php echo $anatomy_face['url_5']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_5">
                    <option value="same_window" <?php if($anatomy_face['turl_5'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_5'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_5'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_5"><?php echo $anatomy_face['info_5']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">MOUTH</p>
            <span class="chkbx"><input type="checkbox" name="enabled_6" value="1" <?php if ($anatomy_face['enabled_6'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_6" value="<?php echo $anatomy_face['url_6']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_6">
                    <option value="same_window" <?php if($anatomy_face['turl_6'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_6'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_6'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_6"><?php echo $anatomy_face['info_6']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">EAR [RT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_7" value="1" <?php if ($anatomy_face['enabled_7'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_7" value="<?php echo $anatomy_face['url_7']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_7">
                    <option value="same_window" <?php if($anatomy_face['turl_7'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_7'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_7'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_7"><?php echo $anatomy_face['info_7']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">EAR [LT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_8" value="1" <?php if ($anatomy_face['enabled_8'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_8" value="<?php echo $anatomy_face['url_8']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_8">
                    <option value="same_window" <?php if($anatomy_face['turl_8'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_8'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_8'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_8"><?php echo $anatomy_face['info_8']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">CHEEK [RT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_9" value="1" <?php if ($anatomy_face['enabled_9'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_9" value="<?php echo $anatomy_face['url_9']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_9">
                    <option value="same_window" <?php if($anatomy_face['turl_9'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_9'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_9'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_9"><?php echo $anatomy_face['info_9']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">CHEEK [LT]</p>
            <span class="chkbx"><input type="checkbox" name="enabled_10" value="1" <?php if ($anatomy_face['enabled_10'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_10" value="<?php echo $anatomy_face['url_10']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_10">
                    <option value="same_window" <?php if($anatomy_face['turl_10'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_10'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_10'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_10"><?php echo $anatomy_face['info_10']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">CHIN</p>
            <span class="chkbx"><input type="checkbox" name="enabled_11" value="1" <?php if ($anatomy_face['enabled_11'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_11" value="<?php echo $anatomy_face['url_11']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_11">
                    <option value="same_window" <?php if($anatomy_face['turl_11'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_11'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_11'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_11"><?php echo $anatomy_face['info_11']; ?></textarea></p></div>
            </div>
          </div>

          <div class="org-area"><p class="area-name">NECK</p>
            <span class="chkbx"><input type="checkbox" name="enabled_12" value="1" <?php if ($anatomy_face['enabled_12'] == '1'){echo " checked";} ?>>&nbsp;Active</span>
            <div class="inner-content">
              <div class="area-url">
                <p class="link"><label>Link</label><input type="text" name="url_12" value="<?php echo $anatomy_face['url_12']; ?>" /></p>
                <p><label>Target</label>
                  <select name="turl_12">
                    <option value="same_window" <?php if($anatomy_face['turl_12'] == 'same_window'){echo "selected";} ?>>Same Page</option>
                    <option value="new_window" <?php if($anatomy_face['turl_12'] == 'new_window'){echo "selected";} ?>>New Page</option>
                    <option value="none" <?php if($anatomy_face['turl_12'] == 'none'){echo "selected";} ?>>None / Modal</option>
                  </select>
                </p>
              </div>
              <div class="info"><p><textarea rows="5" name="info_12"><?php echo $anatomy_face['info_12']; ?></textarea></p></div>
            </div>
          </div>

        </div><!-- box-body / for areas -->
      </div><!-- anatomy-settings / for areas -->
    </div><!-- anatomy-col-lt -->

    <!-- General anatomy Colors -->
    <div class="anatomy-col-rt">
      <div class="anatomy-settings">
        <div class="box-header shape-icon">General Settings</div>
        <div class="box-body">
          <div class="general-box"><span class="general-set i-border">Outline Color</span><input type="text" name="outlineColor" value="<?php echo $anatomy_face['outlineColor']; ?>" class="color-field" /></div>
        </div><!-- box-body -->
      </div><!-- anatomy-settings -->
      <p><strong>Hint:</strong> you can hide the outline by setting its value as <strong><i>transparent</i></strong></p>
    </div><!-- anatomy-col-rt -->

    <input type="hidden" name="anatomy_face">
      <?php
      settings_fields(__FILE__);
      do_settings_sections(__FILE__);
      ?>
    <p class="anatomy-btns"><span class="submit"><input type="submit" name="restore_default" id="submit" class="button" value="Restore Default"></span></p>
    <div class="scroll-top"><span class="scroll-top-icon"></span></div>
    <!--scroll-top script-->
    <script>
      jQuery(function(){jQuery(document).on( 'scroll', function(){ if (jQuery(window).scrollTop() > 100) {jQuery('.scroll-top').addClass('show');} else {jQuery('.scroll-top').removeClass('show');}});jQuery('.scroll-top').on('click', scrollToTop);});function scrollToTop() {verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;element = jQuery('body');offset = element.offset();offsetTop = offset.top -32;jQuery('html, body').animate({scrollTop: offsetTop}, 500, 'linear');}
    </script>

  </div><!-- anatomy-page -->
</div><!-- anatomy-admin -->
</form>
