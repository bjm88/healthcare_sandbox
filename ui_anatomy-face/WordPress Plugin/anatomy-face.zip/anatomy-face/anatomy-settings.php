<?php $anatomy_face = $this->options; ?>
var anaconfig = {
	'default':{
		'outlineColor':'<?php echo $anatomy_face['outlineColor']; ?>',
	}<?php echo (isset($anatomy_face['url_1']))?',':''; ?><?php $i = 1; 	while (isset($anatomy_face['url_'.$i])) { ?>'ana<?php echo $i; ?>':{
		'hover': '<?php echo str_replace(array("\n","\r","\r\n","'"),array('','','','’'), is_array($anatomy_face['info_'.$i]) ?
				array_map('stripslashes_deep', $anatomy_face['info_'.$i]) : stripslashes($anatomy_face['info_'.$i])); ?>',
		'url':'<?php echo $anatomy_face['url_'.$i]; ?>',
		'target':'<?php echo $anatomy_face['turl_'.$i]; ?>',
		'enabled':<?php echo $anatomy_face['enabled_'.$i]=='1'?'true':'false'; ?>,
		}
		<?php echo (isset($anatomy_face['url_'.($i+1)]))?',':''; ?><?php $i++;} ?>
}