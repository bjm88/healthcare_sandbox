<?php
/*
Plugin Name: Anatomy [Face]
Plugin URI: https://www.humananatomyillustrations.com/interactive-human-face-anatomy.html
Description: Customize each part of the face (link, hover info., etc) through the dashboard and use the shortcode in your page(s).
Version: 2.3
Author: Interactive Anatomy Apps
Author URI: https://www.humananatomyillustrations.com/
*/

class ANATOMYFACE {

	public function __construct(){
		$this->constant();
		$this->options = get_option( 'anatomy_face' );
		add_action( 'admin_menu', array($this, 'anatomy_face_options_page') );
	 	add_action( 'admin_footer', array( $this,'add_js_to_wp_footer') );
	 	add_action( 'wp_footer', array($this,'add_span_tag') );
		add_action( 'admin_enqueue_scripts', array($this,'init_admin_script') );
		add_shortcode( 'anatomy_face', array($this, 'anatomy_face') );
		$this->default = array(
			'outlineColor' => '#FF0000',
		);
		foreach (array(
			'FULL FACE', 'FOREHEAD', 'EYE [RT]', 'EYE [LT]', 'NOSE', 'MOUTH', 'EAR [RT]', 'EAR [LT]', 'CHEEK [RT]', 'CHEEK [LT]', 'CHIN', 'NECK'
		) as $k=>$area) {
			$this->default['url_'.($k+1)] = '';
			$this->default['turl_'.($k+1)] = 'same_window';
			$this->default['info_'.($k+1)] = $area;
			$this->default['enabled_'.($k+1)] = 1;
		}
		if(isset($_POST['anatomy_face']) && !isset($_POST['preview_anatomy'])){
			update_option('anatomy_face', array_map('stripslashes_deep', $_POST));
			$this->options = array_map('stripslashes_deep', $_POST);
		}
		if(isset($_POST['anatomy_face']) && isset($_POST['restore_default'])){
			update_option('anatomy_face', $this->default);
			$this->options = $this->default;
		}
		if(!is_array($this->options)){
			$this->options = $this->default;
		}
	}

	protected function constant(){
		define( 'ANATOMYFACE_VERSION', '1.0' );
		define( 'ANATOMYFACE_DIR', plugin_dir_path( __FILE__ ) );
		define( 'ANATOMYFACE_URL', plugin_dir_url( __FILE__ ) );
	}

	public function anatomy_face(){
		ob_start();
		include 'design/anatomy.php';
		?>
		<script type="text/javascript">
			<?php include 'anatomy-settings.php'; ?>
		</script>
		<?php
		wp_enqueue_style( 'anatomystyle-frontend', ANATOMYFACE_URL . 'illustration-style.css', false, '1.0', 'all' );
		wp_enqueue_script( 'interact-script', ANATOMYFACE_URL . 'interact-script.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'spots-settings', ANATOMYFACE_URL . 'spots-settings.js', array('jquery'), 10, '1.0', true );
		$html = ob_get_clean();
		return $html;
	}

	public function anatomy_face_options_page() {
		add_menu_page('Anatomy [Face]', 'Anatomy [Face]', 'manage_options', 'anatomy-face', array($this, 'options_screen'), ANATOMYFACE_URL . 'images/anatomy-icon.png');
	}

	public function admin_ajax_url(){
		$url_action = admin_url( '/' ) . 'admin-ajax.php';
		echo '<div style="display:none" id="wpurl">'. $url_action.'</div>';
	}

	public function options_screen(){ ?>
		<script type="text/javascript">
			<?php include 'anatomy-settings.php'; ?>
		</script>
	<?php include 'design/ana-dashboard.php';
	}

	public function add_js_to_wp_footer(){ ?>
	<span id="anatip" style="margin-top:-32px"></span>
	<?php }

	public function add_span_tag(){
		?>
		<span id="anatip"></span>
		<?php
	}

	public function stripslashes_deep($value) {
		$value = is_array($value) ?
		array_map(array($this, 'stripslashes_deep'), $value) : stripslashes($value);
		return $value;
	}

	public function init_admin_script(){
		if(isset($_GET['page']) && $_GET['page'] == 'anatomy-face'):
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style('thickbox');
		wp_enqueue_script('thickbox');
		wp_enqueue_script( 'media-upload');
		wp_enqueue_style( 'anatomy-style', ANATOMYFACE_URL . 'anatomy-dashboard.css', false, '1.0', 'all' );
		wp_enqueue_style( 'anatomystyle', ANATOMYFACE_URL . 'illustration-style.css', false, '1.0', 'all' );
		wp_enqueue_style( 'wp-tinyeditor', ANATOMYFACE_URL . 'tinyeditor.css', false, '1.0', 'all' );
		wp_enqueue_script( 'interact-script', ANATOMYFACE_URL . 'interact-script.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'spots-settings', ANATOMYFACE_URL . 'spots-settings.js', array('jquery'), 10, '1.0', true );
		wp_enqueue_script( 'anatomy-tiny.editor', ANATOMYFACE_URL . 'js/tinymce.min.js', 10, '1.0', true );
		wp_enqueue_script( 'anatomy-script', ANATOMYFACE_URL . 'js/scripts.js', array( 'wp-color-picker' ), false, true );
		endif;
	}
}

$anatomy_face = new ANATOMYFACE();